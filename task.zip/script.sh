echo "$(/usr/spark/spark-2.3.3-bin-hadoop2.7/bin/spark-submit file.py)"
