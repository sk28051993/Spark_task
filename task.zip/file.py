#/usr/spark/spark-2.3.3-bin-hadoop2.7/bin/spark-submit file.py
import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

df = spark.read.format("csv").option("header", "true").load("/home/sagar/Videos/nonConfidential.csv")
#df.show()
parDF=spark.read.parquet("/home/sagar/Videos/confidential.snappy.parquet")
#parDF.show(50)

mergeDf = df.union(parDF) #as bothe the table has same number of columns
mergeDf.show()


#How many LEED projects are there in Virginia (including all types of project types and versions of LEED)?

sample = mergeDf.filter(mergeDf["City"] == "Virginia Beach").show()
print(sample.distinct().count())

# What is the number of LEED projects in Virginia by owner type?
sample2 = mergeDf.filter(mergeDf["OwnerTypesLEEDSystemVersionDisplayName"] == mergeDf.OwnerTypesLEEDSystemVersionDisplayName.like("% LEED %")).show()
print(sample2.distinct().count())

#What Zip Code in Virginia has the highest number of projects? 
sample4 = spark.sql(mergeDf.groupBy("Zipcode").count().show())
spark.sql(max(count)).show()
