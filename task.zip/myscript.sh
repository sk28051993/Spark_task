echo "$(bash script.sh)">output.txt 
